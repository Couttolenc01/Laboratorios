const express = require('express');
const app = express();
app.set('view engine', 'ejs');
const Router = require('./routes/app.routes.js');
app.get('/classics', Router);
app.get('/sport', Router);
app.get('/allTerrain', Router);




app.get('/', (req, res) => {
  res.render('index');
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});
