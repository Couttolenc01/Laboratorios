const { cars, Car } = require("../models/cars");

// Add a new car
const newCar = new Car("Tesla", "Model S", 2022);
cars.push(newCar);

// Print the updated list of cars
console.log(cars);
