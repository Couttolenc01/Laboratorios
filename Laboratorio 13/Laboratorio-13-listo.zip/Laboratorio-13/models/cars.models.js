let cars = [];

class Car {
  constructor(make, model, year) {
    this.id = Math.floor(Math.random() * 1000); // Generate a random ID
    this.make = make;
    this.model = model;
    this.year = year;
  }
}

// Add some initial cars for testing purposes
cars.push(new Car("Toyota", "Corolla", 2022));
cars.push(new Car("Honda", "Civic", 2023));
cars.push(new Car("Ford", "Mustang", 2021));

// Export the cars array and the Car class
module.exports = {
  cars,
  Car,
};
