const express = require('express');
const router = express.Router();


router.get('/classics',(request,response)=> {
    response.setHeader('ContentType', 'text/html');
    response.render('classics');
});

router.get('/sport',(request,response)=> {
    response.setHeader('ContentType', 'text/html');
    response.render('sport');
});

router.get('/allTerrain',(request,response)=> {
    response.setHeader('ContentType', 'text/html');
    response.render('allTerrain');
});

module.exports = router;

