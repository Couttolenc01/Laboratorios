// const connection = require('../util/database');
var games = [];
const rapidGames = [];
var ChessWebAPI = require('chess-web-api');
var chessAPI = new ChessWebAPI();

// const queryPromise = new Promise((resolve, reject) => {
//   connection.query('SELECT * FROM games', (error, results, fields) => {
//     if (error) {
//       console.error('Error buscando games: ' + error.stack);
//       reject(error);
//       return;
//     }

//     results.forEach(game => {
//       const gameData = {
//         id: game.id,
//         white: game.white,
//         black: game.black,
//         ratingWhite: game.ratingWhite,
//         ratingBlack: game.ratingBlack,
//         moves: game.moves
//       };

//       games.push(gameData);
//     });

//     resolve();
//   });
// });

// queryPromise.then(() => {
//   console.log('Query finalizada.');
//   connection.end();
// }).catch(error => {
//   console.error('Error en la query:', error);
// });


chessAPI.getPlayerCompleteMonthlyArchives('TheThunderboltking', '2023','4').then(function(response) {
  var i = 0;
p0- = response.body.games
  for(var key in games) {
    if(games[key].time_class == 'rapid'){
      const regex = /\{[^{}]+\}/g;
      rapidGames.push({
        id: i,
        white: games[key].white.username,
        black: games[key].black.username,
        ratingWhite: games[key].white.rating,
        ratingBlack: games[key].black.rating,
        moves: games[key].pgn.replace(regex, '').replace(/(\d+\.\s)/g, '$1').replace(/\s+\d+\.\.\./g, " ").split("\n").filter(line => !line.startsWith('[')).join('\n').replace(/\n/g, '')
        })
      i++;
    }
  }
      console.log(rapidGames[0].moves)
});

module.exports = rapidGames;
